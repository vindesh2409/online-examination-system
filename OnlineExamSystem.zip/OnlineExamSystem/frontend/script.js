// Placeholder for future frontend JS (e.g., client-side timer/validation)
console.log("Online Exam frontend loaded");
