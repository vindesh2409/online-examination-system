package model;
public class Question {
    private int id;
    private String question;
    private String opt1,opt2,opt3,opt4;
    private int answer;
    // getters and setters
    public int getId(){return id;}
    public void setId(int id){this.id=id;}
    public String getQuestion(){return question;}
    public void setQuestion(String q){this.question=q;}
    public String getOpt1(){return opt1;}
    public void setOpt1(String o){this.opt1=o;}
    public String getOpt2(){return opt2;}
    public void setOpt2(String o){this.opt2=o;}
    public String getOpt3(){return opt3;}
    public void setOpt3(String o){this.opt3=o;}
    public String getOpt4(){return opt4;}
    public void setOpt4(String o){this.opt4=o;}
    public int getAnswer(){return answer;}
    public void setAnswer(int a){this.answer=a;}
}
