package servlet;
import model.DBConnection;
import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.sql.*;

@WebServlet("/submitExam")
public class SubmitExamServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        HttpSession session = req.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        if (userId == null) { res.sendRedirect("login.jsp"); return; }
        int score = 0;
        try {
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM questions");
            while (rs.next()) {
                String qId = "q" + rs.getInt("id");
                String userAns = req.getParameter(qId);
                if (userAns != null && Integer.parseInt(userAns) == rs.getInt("answer")) score++;
            }
            PreparedStatement ps = con.prepareStatement("INSERT INTO results(user_id,score) VALUES(?,?)");
            ps.setInt(1,userId);
            ps.setInt(2,score);
            ps.executeUpdate();
            res.sendRedirect("result.jsp?score=" + score);
        } catch (Exception e) { e.printStackTrace(); res.sendRedirect("exam.jsp?error=1"); }
    }
}
