package servlet;
import model.DBConnection;
import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.sql.*;

@WebServlet("/addQuestion")
public class AddQuestionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        String q = req.getParameter("question");
        String o1 = req.getParameter("opt1");
        String o2 = req.getParameter("opt2");
        String o3 = req.getParameter("opt3");
        String o4 = req.getParameter("opt4");
        int ans = Integer.parseInt(req.getParameter("answer"));
        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("INSERT INTO questions(question,opt1,opt2,opt3,opt4,answer) VALUES(?,?,?,?,?,?)");
            ps.setString(1,q);
            ps.setString(2,o1);
            ps.setString(3,o2);
            ps.setString(4,o3);
            ps.setString(5,o4);
            ps.setInt(6,ans);
            ps.executeUpdate();
            res.sendRedirect("admin/addQuestion.jsp?success=1");
        } catch (Exception e) { e.printStackTrace(); res.sendRedirect("admin/addQuestion.jsp?error=1"); }
    }
}
