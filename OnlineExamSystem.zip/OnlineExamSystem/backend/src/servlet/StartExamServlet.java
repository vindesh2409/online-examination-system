package servlet;
import model.DBConnection;
import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.sql.*;

@WebServlet("/startExam")
public class StartExamServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        // redirect to exam page which loads questions from DB (exam.jsp)
        res.sendRedirect("exam.jsp");
    }
}
