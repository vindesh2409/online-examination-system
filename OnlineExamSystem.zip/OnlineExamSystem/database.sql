CREATE DATABASE IF NOT EXISTS online_exam;
USE online_exam;

CREATE TABLE IF NOT EXISTS users(
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50),
    email VARCHAR(50) UNIQUE,
    password VARCHAR(255),
    role VARCHAR(10)
);

CREATE TABLE IF NOT EXISTS questions(
    id INT PRIMARY KEY AUTO_INCREMENT,
    question TEXT,
    opt1 VARCHAR(200),
    opt2 VARCHAR(200),
    opt3 VARCHAR(200),
    opt4 VARCHAR(200),
    answer INT
);

CREATE TABLE IF NOT EXISTS results(
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    score INT,
    exam_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- sample admin user (password is 'admin' plain — change in production)
INSERT INTO users (name, email, password, role) VALUES
('Admin', 'admin@example.com', 'admin', 'admin');
