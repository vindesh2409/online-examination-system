# Online Examination System (MCQ Test)
Frontend: HTML/CSS/JavaScript
Backend: Java Servlets/JSP + MySQL

## What is included
- frontend/
  - index.html
  - styles.css
  - script.js
- backend/
  - src/
    - model/
      - DBConnection.java
      - User.java
      - Question.java
    - servlet/
      - LoginServlet.java
      - RegisterServlet.java
      - AddQuestionServlet.java
      - StartExamServlet.java
      - SubmitExamServlet.java
  - webapp/
    - login.jsp
    - register.jsp
    - exam.jsp
    - result.jsp
    - admin/
      - addQuestion.jsp
      - viewQuestions.jsp
- database.sql

## Setup (local)
1. Install MySQL and create database using `database.sql`.
2. Configure DB credentials in backend/src/model/DBConnection.java.
3. Build as a WAR for a Servlet container (e.g., Apache Tomcat). Place `webapp` files under webapp/ in your project.
4. Compile Java sources and deploy.
5. Open `frontend/index.html` or use the deployed webapp URLs.

This package is a starter template — adjust and harden (password hashing, validation, prepared statements, sessions).
